from setuptools import setup

setup(name="tool_sample",
	version ="0.1.0",
	packages=["tool"])
