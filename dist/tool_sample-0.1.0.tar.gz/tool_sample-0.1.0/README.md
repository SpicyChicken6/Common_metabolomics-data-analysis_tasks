# project576

**Tool development for bioinf576 class**

Implement a Python based pipeline related to metabolomics data analysis, since I will be working with metabolomics data this semester, I feel like I will be interested in automating the workflow for the metabolomics data analysis. I haven’t got the data to work with yet, but hopefully starting this week! Then I will have a better idea of what I should do for this pipeline.
