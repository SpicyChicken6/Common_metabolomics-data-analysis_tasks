from setuptools import setup

setup(name="Common_metabolomics-data-analysis_tools",
	version ="0.1.0",
	packages=["tool"])
