from setuptools import setup

setup(name="metabolomics_analysis_tools",
	version ="0.1.0",
	packages=["modules"])
