def x_y_sum(x, y):
    return x + y
